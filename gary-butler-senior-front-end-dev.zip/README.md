##checkout app

This app has been created with javascript and html.

development enviroment: 'yarn start'
test: 'yarn test'
production enviroment: 'yarn build'

In development enviroment the project will load with webpack-dev-server. The project is a static build so once built, it will work if you open the index.html file locally in your Browser.
